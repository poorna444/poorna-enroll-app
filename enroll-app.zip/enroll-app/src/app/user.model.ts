export class User {
    name: string;
    id: string;
    active: boolean;
    dateOfBirth?: string;
}
