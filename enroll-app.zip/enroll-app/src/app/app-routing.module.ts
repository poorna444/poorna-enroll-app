import { EnrollDetailsComponent } from './enroll-details/enroll-details.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EnrollListComponent } from './enroll-list/enroll-list.component';

const routes: Routes = [
  {
    path: 'enrolls',
    component: EnrollListComponent
  },
  {
    path: 'edit-enroll/:id',
    component: EnrollDetailsComponent
  },
  { path: '', redirectTo: 'enrolls', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
